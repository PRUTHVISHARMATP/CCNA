/**
 * Authentication Routes File (auth.routes.js)
 * 
 * Ye file authentication-related routes define karti hai
 * Routes = URL endpoints jo frontend se requests receive karte hain
 * Yahan sirf route definitions hain - business logic controllers mein hogi
 */

// ============================================================================
// EXPRESS ROUTER IMPORT
// ============================================================================

// Express library import kar rahe hain - Router functionality ke liye
// Express framework HTTP requests handle karne ke liye use hota hai
const express = require('express');

// express.Router() se router instance create kar rahe hain
// Router kya hai? - Ye mini Express app hota hai jo routes manage karta hai
// Router use kyun karte hain app instance directly use karne ki jagah?
// 1. Modularity: Har feature ka apna router - code organize rehta hai
// 2. Scalability: Multiple routers alag-alag files mein - maintain karna easy
// 3. Reusability: Router ko easily mount/unmount kar sakte hain
// 4. Clean Code: app.js clean rehta hai - sab routes alag files mein
// 5. Testing: Router ko individually test kar sakte hain
const router = express.Router();

// ============================================================================
// AUTH CONTROLLER IMPORT
// ============================================================================

// Authentication controller import kar rahe hain
// Controllers request/response handle karte hain - business logic services mein hoti hai
// Controller functions: login, logout, getCurrentUser, register
// Path: '../../controllers/auth.controller' - routes/auth folder se controllers folder
const {
  login,
  logout,
  getCurrentUser,
  register,
  updateProfile,
  uploadProfilePhoto,
  getProfilePhoto
} = require('../../controllers/auth.controller');

const { getActivityLogs } = require('../../controllers/activity-log.controller');

// Auth Service import kar rahe hain - Approval system functions ke liye
const authService = require('../../services/auth.service');

// Authentication middleware import kar rahe hain
// Protected routes ke liye authentication check karne ke liye
const authMiddleware = require('../../middleware/auth.middleware');

// Admin-only access guard
const requireAdmin = (req, res, next) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Access denied. Admin privileges required.'
    });
  }
  return next();
};

// Try to import multer - if not available, create a fallback
let upload;
try {
  const multer = require('multer');
  upload = multer({
    storage: multer.memoryStorage(),
    limits: {
      fileSize: 5 * 1024 * 1024 // 5MB max file size
    },
    fileFilter: (req, file, cb) => {
      // Allow only image files
      const allowedMimes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
      if (allowedMimes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error('Invalid file type. Only images are allowed.'), false);
      }
    }
  });
} catch (err) {
  console.warn('⚠️ Multer not installed. Install with: npm install multer');
  // Fallback middleware that just passes through
  upload = {
    single: (fieldName) => (req, res, next) => {
      console.log('⚠️ Multer fallback: install multer package for file uploads');
      next();
    }
  };
}

// ============================================================================
// ROUTES KYA HAIN? (What are Routes?)
// ============================================================================

/**
 * Routes Kya Hain?
 * - Routes = URL endpoints jo frontend se HTTP requests receive karte hain
 * - Example: POST /api/auth/login - login endpoint
 * - Har route = URL pattern + HTTP method (GET, POST, PUT, DELETE) + handler function
 * 
 * Request Flow: Route → Controller → Service → Database
 * 
 * 1. Frontend se request aata hai: POST /api/auth/login (email, password ke saath)
 * 2. Route catch karta hai: router.post('/login', login) - login controller call hota hai
 * 3. Controller execute hota hai: login(req, res) - request validate karta hai, service call karta hai
 * 4. Service business logic handle karta hai: authService.login() - database query, password verify, token generate
 * 5. Database query execute hoti hai: User find karna, password match karna
 * 6. Response wapas jata hai: Service → Controller → Route → Frontend
 * 
 * Kyun Auth Routes Alag File Mein?
 * - Separation of Concerns: Har feature ka apna routes file - organization better
 * - Maintainability: Auth routes change karni ho to sirf ye file edit karni hai
 * - Scalability: Naye routes easily add kar sakte hain - file structure clear rehta hai
 * - Team Collaboration: Multiple developers alag-alag route files par kaam kar sakte hain
 * - Clean Architecture: app.js clean rehta hai - har feature modular
 */

// ============================================================================
// AUTHENTICATION ROUTES DEFINITION
// ============================================================================

/**
 * POST /login - User Login Route
 * 
 * Request: POST /api/auth/login
 * Body: { email: "user@example.com", password: "password123" }
 * 
 * Flow:
 * - Frontend login form se email/password bhejta hai
 * - Route login controller function ko call karta hai
 * - Controller authService.login() call karke credentials verify karta hai
 * - Service database se user find karta hai, password verify karta hai, JWT token generate karta hai
 * - Controller response mein token aur user info return karta hai
 * 
 * Response: { success: true, data: { token: "...", user: {...} } }
 */
router.post('/login', login);

/**
 * POST /logout - User Logout Route
 * 
 * Request: POST /api/auth/logout
 * Headers: { Authorization: "Bearer <token>" }
 * 
 * Flow:
 * - Frontend logout button click karne pe request bhejta hai
 * - Route logout controller function ko call karta hai
 * - Controller stateless JWT logout handle karta hai (token client-side remove hoga)
 * - Optional: Token blacklisting implement kar sakte hain service mein
 * 
 * Response: { success: true, message: "Logout successful" }
 */
router.post('/logout', logout);

/**
 * GET /me - Get Current User Profile Route
 * 
 * Request: GET /api/auth/me
 * Headers: { Authorization: "Bearer <token>" }
 * 
 * Flow:
 * - Frontend current user ki profile info fetch karna chahta hai
 * - Auth middleware token verify karke req.user mein user data populate karta hai
 * - Route getCurrentUser controller function ko call karta hai
 * - Controller req.user se user info read karke response return karta hai
 * 
 * Note: Ye route protected hai - authentication middleware required hoga
 * 
 * Response: { success: true, data: { user: { id, email, role, ... } } }
 */
router.get('/me', authMiddleware, getCurrentUser);

/**
 * POST /register - User Registration Route (Optional)
 * 
 * Request: POST /api/auth/register
 * Body: { email: "user@example.com", password: "password123", role: "student", name: "John Doe" }
 * 
 * Flow:
 * - Frontend registration form se user data bhejta hai
 * - Route register controller function ko call karta hai
 * - Controller validation karke authService.register() call karta hai
 * - Service database mein naya user create karta hai, password hash karta hai
 * - Controller response mein user info return karta hai
 * 
 * Note: Ye route optional hai - agar system mein registration allowed nahi hai to comment out kar do
 * 
 * Response: { success: true, data: { user: { id, email, role, ... } } }
 */
router.post('/register', register);

router.post('/signup-request', async (req, res) => {
  try {
    const payload = {
      ...req.body,
      contactNumber: req.body?.contactNumber || req.body?.contact_number,
      studentId: req.body?.studentId || req.body?.student_id,
      teacherId: req.body?.teacherId || req.body?.teacher_id,
    };
    const result = await authService.submitSignupRequest(payload);
    return res.status(202).json({
      success: true,
      message: 'Signup request submitted. Please wait for admin approval.',
      data: result,
    });
  } catch (error) {
    if (error.statusCode) {
      return res.status(error.statusCode).json({
        success: false,
        message: error.message,
      });
    }
    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to submit signup request.',
      error: error.message,
    });
  }
});

/**
 * GET /students - Get All Students (Admin Only)
 * 
 * Request: GET /api/auth/students
 * Headers: { Authorization: "Bearer <admin_token>" }
 * 
 * Response: { success: true, data: [...students] }
 * 
 * Returns registered students from users table PLUS approved but not-yet-registered students
 */
router.get('/students', async (req, res) => {
  try {
    const { pool } = require('../../config/database');
    
    // Get registered students from users table
    const [registeredStudents] = await pool.query(
      `SELECT id, name, email, student_id, department, semester, is_active, created_at, 'registered' as status
       FROM users 
       WHERE role = 'student' 
       ORDER BY department ASC, semester ASC, name ASC`
    );
    
    // Get approved but not-yet-registered students from approved_users table
    let approvedPendingStudents = [];
    try {
      const [approved] = await pool.query(
        `SELECT 
          id, 
          name, 
          email, 
          student_id, 
          department, 
          semester, 
          1 as is_active, 
          created_at,
          'approved_pending' as status
         FROM approved_users 
         WHERE role = 'student' 
         AND is_registered = FALSE 
         AND approval_status = 'approved'
         ORDER BY department ASC, semester ASC, name ASC`
      );
      approvedPendingStudents = approved || [];
    } catch (approvedError) {
      // approved_users table might not exist - that's ok, just log and continue
      console.warn('approved_users table not available:', approvedError.message);
    }
    
    // Combine both lists
    const allStudents = [...(registeredStudents || []), ...approvedPendingStudents];
    
    return res.status(200).json({
      success: true,
      message: `Students retrieved successfully (${registeredStudents?.length || 0} registered, ${approvedPendingStudents.length} approved)`,
      data: allStudents || []
    });
  } catch (error) {
    console.error('Error fetching students:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch students'
    });
  }
});

/**
 * PATCH /admin/students/:id/promote - Promote student to next semester
 * - Updates users.semester  (e.g. '1st' → '2nd')
 * - Re-builds course_enrollment for the new semester
 * - If student is in 6th semester → marks as 'graduated' (is_active = 0, semester = 'graduated')
 */
router.patch('/admin/students/:id/promote', authMiddleware, requireAdmin, async (req, res) => {
  const { pool } = require('../../config/database');
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const { id } = req.params;

    // Fetch current student
    const [[student]] = await conn.query(
      `SELECT id, name, semester, department FROM users WHERE id = ? AND role = 'student'`,
      [id]
    );
    if (!student) {
      await conn.rollback();
      return res.status(404).json({ success: false, message: 'Student not found.' });
    }

    const semOrder = ['1st', '2nd', '3rd', '4th', '5th', '6th'];
    const curIdx = semOrder.indexOf(student.semester);

    if (curIdx === -1) {
      await conn.rollback();
      return res.status(400).json({
        success: false,
        message: `Student's semester '${student.semester}' cannot be promoted.`
      });
    }

    // 6th semester → graduate
    if (curIdx === 5) {
      await conn.query(`UPDATE users SET semester = 'graduated', is_active = 0 WHERE id = ?`, [id]);
      await conn.query(`DELETE FROM course_enrollment WHERE student_id = ?`, [id]);
      await conn.commit();
      return res.status(200).json({
        success: true,
        message: `${student.name} has been graduated! 🎓`,
        data: { newSemester: 'graduated', graduated: true }
      });
    }

    const newSemester = semOrder[curIdx + 1];
    const newSemNum  = curIdx + 2; // 1-indexed int for courses table

    // Get department_id
    const [[dept]] = await conn.query(
      `SELECT id FROM departments WHERE name = ?`,
      [student.department]
    );

    // Update semester
    await conn.query(`UPDATE users SET semester = ? WHERE id = ?`, [newSemester, id]);

    // Rebuild enrollments
    await conn.query(`DELETE FROM course_enrollment WHERE student_id = ?`, [id]);

    if (dept) {
      const [courses] = await conn.query(
        `SELECT id FROM courses WHERE department_id = ? AND semester = ? AND is_active = 1`,
        [dept.id, newSemNum]
      );
      if (courses.length > 0) {
        const rows = courses.map(c => [id, c.id]);
        await conn.query(`INSERT INTO course_enrollment (student_id, course_id) VALUES ?`, [rows]);
      }
    }

    await conn.commit();
    return res.status(200).json({
      success: true,
      message: `${student.name} has been promoted to ${newSemester} semester! 🎉`,
      data: { newSemester, graduated: false }
    });
  } catch (error) {
    await conn.rollback();
    console.error('Promote error:', error);
    return res.status(500).json({ success: false, message: 'An error occurred while promoting the student.' });
  } finally {
    conn.release();
  }
});

/**
 * GET /admin/users - Admin user management list
 * Query params: search, role, status (active/inactive)
 * Returns registered users from users table PLUS approved-but-pending users from approved_users
 */
router.get('/admin/users', authMiddleware, requireAdmin, async (req, res) => {
  try {
    const { pool } = require('../../config/database');
    const { search, role, status } = req.query;

    let where = 'WHERE 1=1';
    const params = [];

    if (role && role !== 'all') {
      where += ' AND role = ?';
      params.push(role);
    }

    if (status === 'active') {
      where += ' AND is_active = 1';
    } else if (status === 'inactive') {
      where += ' AND is_active = 0';
    }

    if (search && search.trim()) {
      const like = `%${search.trim()}%`;
      where += ' AND (name LIKE ? OR email LIKE ? OR department LIKE ?)';
      params.push(like, like, like);
    }

    const [registeredUsers] = await pool.query(
      `SELECT id, name, email, role, is_active, department, 'registered' as status
       FROM users
       ${where}
       ORDER BY created_at DESC`,
      params
    );

    // Get approved but not-yet-registered users from approved_users table
    let approvedPendingUsers = [];
    try {
      // Build dynamic query for approved_users based on filters
      let approvedWhere = 'WHERE approval_status = "approved" AND is_registered = FALSE';
      const approvedParams = [];

      if (role && role !== 'all') {
        approvedWhere += ' AND role = ?';
        approvedParams.push(role);
      }

      if (status === 'active') {
        approvedWhere += ' AND 1=1'; // They're always considered active for approved
      } else if (status === 'inactive') {
        approvedWhere += ' AND 0=1'; // Skip if looking for inactive
      }

      if (search && search.trim()) {
        const like = `%${search.trim()}%`;
        approvedWhere += ' AND (name LIKE ? OR email LIKE ? OR department LIKE ?)';
        approvedParams.push(like, like, like);
      }

      const [approved] = await pool.query(
        `SELECT 
          id, 
          name, 
          email, 
          role, 
          1 as is_active, 
          department,
          'approved_pending' as status
         FROM approved_users 
         ${approvedWhere}
         ORDER BY created_at DESC`,
        approvedParams
      );
      approvedPendingUsers = approved || [];
    } catch (approvedError) {
      // approved_users table might not exist - that's ok, just log and continue
      console.warn('approved_users table not available:', approvedError.message);
    }

    // Combine both lists
    const allUsers = [...(registeredUsers || []), ...approvedPendingUsers];

    return res.status(200).json({
      success: true,
      data: allUsers
    });
  } catch (error) {
    console.error('Error fetching users:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch users.'
    });
  }
});

/**
 * GET /admin/logs - Admin activity logs
 * Query params: search, role, action, userId, status, startDate, endDate, page, limit
 */
router.get('/admin/logs', authMiddleware, requireAdmin, getActivityLogs);

/**
 * PATCH /admin/users/:id/role - Update user role
 */
router.patch('/admin/users/:id/role', authMiddleware, requireAdmin, async (req, res) => {
  try {
    const { pool } = require('../../config/database');
    const { id } = req.params;
    const { role } = req.body;
    const allowedRoles = ['student', 'faculty', 'admin'];

    if (!allowedRoles.includes(role)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid role provided.'
      });
    }

    if (Number(id) === Number(req.user?.id)) {
      return res.status(400).json({
        success: false,
        message: 'You cannot change your own role.'
      });
    }

    const [result] = await pool.query(
      'UPDATE users SET role = ? WHERE id = ?',
      [role, id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: 'User not found.'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Role updated successfully.'
    });
  } catch (error) {
    console.error('Error updating role:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to update role.'
    });
  }
});

/**
 * PATCH /admin/users/:id/status - Activate/Deactivate user
 */
router.patch('/admin/users/:id/status', authMiddleware, requireAdmin, async (req, res) => {
  try {
    const { pool } = require('../../config/database');
    const { id } = req.params;
    const { is_active } = req.body;

    if (Number(id) === Number(req.user?.id) && is_active === false) {
      return res.status(400).json({
        success: false,
        message: 'You cannot deactivate your own account.'
      });
    }

    const [result] = await pool.query(
      'UPDATE users SET is_active = ? WHERE id = ?',
      [is_active ? 1 : 0, id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: 'User not found.'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Status updated successfully.'
    });
  } catch (error) {
    console.error('Error updating status:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to update status.'
    });
  }
});

/**
 * DELETE /admin/users/:id - Delete user
 */
router.delete('/admin/users/:id', authMiddleware, requireAdmin, async (req, res) => {
  try {
    const { pool } = require('../../config/database');
    const { id } = req.params;

    if (Number(id) === Number(req.user?.id)) {
      return res.status(400).json({
        success: false,
        message: 'You cannot delete your own account.'
      });
    }

    const [result] = await pool.query(
      'DELETE FROM users WHERE id = ?',
      [id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: 'User not found.'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'User deleted successfully.'
    });
  } catch (error) {
    console.error('Error deleting user:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to delete user.'
    });
  }
});

// ============================================================================
// ROUTER EXPORT
// ============================================================================

/**
 * PUT /profile - Update User Profile
 * 
 * Request: PUT /api/auth/profile
 * Headers: { Authorization: "Bearer <token>" }
 * Body: { name: "New Name", phone: "1234567890", department: "CS" }
 * 
 * Flow:
 * - Frontend sends updated profile data
 * - Auth middleware verifies token and sets req.user
 * - Route calls updateProfile controller
 * - Controller validates and calls service
 * - Service updates database and returns updated user
 * 
 * Response: { success: true, data: { user: {...} } }
 */
router.put('/profile', authMiddleware, updateProfile);

/**
 * POST /upload-photo - Upload Profile Photo
 * 
 * Request: POST /api/auth/upload-photo (FormData)
 * - Body: FormData with field 'photo' containing image file
 * - Headers: Authorization token required
 * 
 * Uploads user's profile photo to database
 * File stored as binary data (BLOB) in database
 * Max file size: 5MB
 * Allowed formats: JPEG, PNG, GIF, WebP
 */
router.post('/upload-photo', authMiddleware, upload.single('photo'), uploadProfilePhoto);

/**
 * GET /photo/:userId - Get Profile Photo
 * 
 * Request: GET /api/auth/photo/123
 * - Params: userId - User ID to get photo for
 * 
 * Returns the user's profile photo as image file
 * Response: Image binary data with appropriate MIME type
 */
router.get('/photo/:userId', getProfilePhoto);

/**
 * ============================================================================
 * APPROVED USERS MANAGEMENT ROUTES (Admin Only)
 * ============================================================================
 * 
 * Jab user pre-approval system active ho to admin isse use karega
 * Admin users ko phele approve karega, phir woh users signup kar sakte hain
 */

/**
 * GET /api/auth/admin/approved-users
 * List all approved users with filters
 * 
 * Query Params:
 * - role: 'student' | 'faculty' | 'all' (default: 'all')
 * - isRegistered: true | false (default: all)
 * - search: Search by name/email/contact
 * 
 * Response: Array of approved users
 */
router.get('/admin/approved-users', authMiddleware, requireAdmin, async (req, res) => {
  try {
    const { role, isRegistered, search, approvalStatus } = req.query;
    
    const filters = {
      role: role || 'all',
      isRegistered: isRegistered === 'true' ? true : isRegistered === 'false' ? false : null,
      search: search?.trim() || '',
      approvalStatus: approvalStatus || 'all',
    };
    
    const approvedUsers = await authService.getAllApprovedUsers(filters);
    
    return res.status(200).json({
      success: true,
      message: 'Approved users retrieved successfully',
      data: approvedUsers
    });
  } catch (error) {
    console.error('Error fetching approved users:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to fetch approved users',
      error: error.message
    });
  }
});

router.patch('/admin/approved-users/:id/status', authMiddleware, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body || {};

    if (!id || Number.isNaN(Number(id))) {
      return res.status(400).json({
        success: false,
        message: 'Invalid approved user ID.',
      });
    }

    const result = await authService.updateApprovedUserStatus(Number(id), status);

    req.activityLogContext = {
      userId: req.user?.id,
      userRole: req.user?.role,
      action: status === 'approved' ? 'ADMIN_APPROVE_SIGNUP_REQUEST' : 'ADMIN_REJECT_SIGNUP_REQUEST',
      entityType: 'approvedUser',
      entityId: id,
    };

    return res.status(200).json({
      success: true,
      message: status === 'approved' ? 'User request approved.' : 'User request rejected.',
      data: result,
    });
  } catch (error) {
    if (error.statusCode) {
      return res.status(error.statusCode).json({
        success: false,
        message: error.message,
      });
    }
    return res.status(500).json({
      success: false,
      message: 'Failed to update approval status.',
      error: error.message,
    });
  }
});

/**
 * POST /api/auth/admin/approved-users
 * Add new approved user (Admin approves user before signup)
 * 
 * Request Body:
 * {
 *   "name": "John Doe",
 *   "email": "john@example.com",
 *   "contactNumber": "9876543210",
 *   "role": "student",          (required: 'student' or 'faculty')
 *   "studentId": "STU001",       (required if role='student')
 *   "teacherId": "TEACH001",     (required if role='faculty')
 *   "department": "CSE",         (optional)
 *   "semester": 4,               (optional)
 *   "section": "A"               (optional)
 * }
 * 
 * Response: Created approved user object
 */
router.post('/admin/approved-users', authMiddleware, requireAdmin, async (req, res) => {
  try {
    const userData = req.body;
    
    const createdApprovedUser = await authService.addApprovedUser(userData);
    
    req.activityLogContext = {
      userId: req.user?.id,
      userRole: req.user?.role,
      action: 'ADMIN_APPROVE_USER',
      entityType: 'approvedUser',
      entityId: String(createdApprovedUser.id)
    };
    
    return res.status(201).json({
      success: true,
      message: 'User approved successfully. They can now register.',
      data: createdApprovedUser
    });
  } catch (error) {
    console.error('Error adding approved user:', error);
    
    if (error.statusCode) {
      return res.status(error.statusCode).json({
        success: false,
        message: error.message
      });
    }
    
    return res.status(500).json({
      success: false,
      message: 'Failed to add approved user',
      error: error.message
    });
  }
});

/**
 * DELETE /api/auth/admin/approved-users/:id
 * Delete approved user (only if not registered yet)
 * 
 * Params:
 * - id: Approved user ID
 * 
 * Response: Success message
 */
router.delete('/admin/approved-users/:id', authMiddleware, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    
    if (!id || isNaN(id)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid approved user ID'
      });
    }
    
    const result = await authService.deleteApprovedUser(Number(id));
    
    req.activityLogContext = {
      userId: req.user?.id,
      userRole: req.user?.role,
      action: 'ADMIN_DELETE_APPROVED_USER',
      entityType: 'approvedUser',
      entityId: id
    };
    
    return res.status(200).json({
      success: true,
      message: result.message
    });
  } catch (error) {
    console.error('Error deleting approved user:', error);
    
    if (error.statusCode) {
      return res.status(error.statusCode).json({
        success: false,
        message: error.message
      });
    }
    
    return res.status(500).json({
      success: false,
      message: 'Failed to delete approved user',
      error: error.message
    });
  }
});

/**
 * POST /api/auth/admin/approved-users/bulk
 * Bulk add approved users via CSV-like JSON array
 * 
 * Request Body:
 * {
 *   "users": [
 *     { "name": "John Doe", "email": "john@example.com", "contactNumber": "9876543210", "role": "student", "studentId": "STU001", "department": "CSE", "semester": 4 },
 *     ...
 *   ]
 * }
 * 
 * Response: { success, total, added, failed, results: [{ row, status, name, email, error? }] }
 */
router.post('/admin/approved-users/bulk', authMiddleware, requireAdmin, async (req, res) => {
  try {
    const { users } = req.body;

    if (!Array.isArray(users) || users.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a non-empty "users" array.'
      });
    }

    if (users.length > 500) {
      return res.status(400).json({
        success: false,
        message: 'Maximum 500 users allowed per bulk upload.'
      });
    }

    const results = [];
    let addedCount = 0;
    let failedCount = 0;

    for (let i = 0; i < users.length; i++) {
      const row = i + 1;
      const userData = users[i];
      try {
        const created = await authService.addApprovedUser(userData);
        addedCount++;
        results.push({ row, status: 'success', name: created.name, email: created.email });
      } catch (err) {
        failedCount++;
        results.push({
          row,
          status: 'failed',
          name: userData.name || '—',
          email: userData.email || '—',
          error: err.message || 'Unknown error'
        });
      }
    }

    req.activityLogContext = {
      userId: req.user?.id,
      userRole: req.user?.role,
      action: 'ADMIN_BULK_APPROVE_USERS',
      entityType: 'approvedUser',
      entityId: `bulk-${addedCount}`
    };

    return res.status(200).json({
      success: true,
      message: `Bulk upload complete: ${addedCount} added, ${failedCount} failed out of ${users.length}.`,
      total: users.length,
      added: addedCount,
      failed: failedCount,
      results
    });
  } catch (error) {
    console.error('Error in bulk approved users:', error);
    return res.status(500).json({
      success: false,
      message: 'Bulk upload failed.',
      error: error.message
    });
  }
});

/**
 * POST /api/auth/admin/teachers
 * Directly create a teacher account (users table) with a set password.
 * Admin provides all details including initial password — teacher can log in immediately.
 * No separate sign-up step required.
 *
 * Body: { name, email, contactNumber, teacherId, department, password, confirmPassword }
 */
router.post('/admin/teachers', authMiddleware, requireAdmin, async (req, res) => {
  try {
    const { pool } = require('../../config/database');
    const bcrypt = require('bcrypt');

    const {
      name,
      email,
      contactNumber,
      teacherId,
      department,
      password,
      confirmPassword
    } = req.body;

    // ── Validate required fields ──────────────────────────────────────────────
    if (!name || !email || !contactNumber || !teacherId || !password) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, contact number, teacher ID and password are all required.'
      });
    }

    if (!/^\d{10}$/.test(String(contactNumber).trim())) {
      return res.status(400).json({
        success: false,
        message: 'Contact number must be exactly 10 digits.'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters.'
      });
    }

    if (password !== confirmPassword) {
      return res.status(400).json({
        success: false,
        message: 'Passwords do not match.'
      });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const normalizedTeacherId = String(teacherId).trim().toUpperCase();

    // ── Check uniqueness ──────────────────────────────────────────────────────
    const [existingEmail] = await pool.query(
      'SELECT id FROM users WHERE LOWER(email) = ?',
      [normalizedEmail]
    );
    if (existingEmail.length > 0) {
      return res.status(409).json({
        success: false,
        message: 'A user with this email already exists.'
      });
    }

    const [existingTeacherId] = await pool.query(
      'SELECT id FROM users WHERE teacher_id = ?',
      [normalizedTeacherId]
    );
    if (existingTeacherId.length > 0) {
      return res.status(409).json({
        success: false,
        message: 'This Teacher ID is already in use.'
      });
    }

    // ── Create user with hashed password ──────────────────────────────────────
    const hashedPassword = await bcrypt.hash(password, 10);

    const [insertResult] = await pool.query(
      `INSERT INTO users
         (name, email, contact_number, password, role, teacher_id, department, is_active, created_at, updated_at)
       VALUES (?, ?, ?, ?, 'faculty', ?, ?, 1, NOW(), NOW())`,
      [
        name.trim(),
        normalizedEmail,
        String(contactNumber).trim(),
        hashedPassword,
        normalizedTeacherId,
        department?.trim() || null
      ]
    );

    const newUserId = insertResult.insertId;

    // ── Also record in approved_users (already registered) ────────────────────
    await pool.query(
      `INSERT INTO approved_users
         (name, email, contact_number, role, teacher_id, department, is_registered, registered_user_id, created_at, updated_at)
       VALUES (?, ?, ?, 'faculty', ?, ?, 1, ?, NOW(), NOW())
       ON DUPLICATE KEY UPDATE
         is_registered = 1,
         registered_user_id = ?,
         updated_at = NOW()`,
      [
        name.trim(),
        normalizedEmail,
        String(contactNumber).trim(),
        normalizedTeacherId,
        department?.trim() || null,
        newUserId,
        newUserId
      ]
    );

    // ── Send credentials email to teacher ─────────────────────────────────────
    try {
      const { sendTeacherCredentialsEmail } = require('../../config/email');
      await sendTeacherCredentialsEmail(
        normalizedEmail,
        name.trim(),
        normalizedTeacherId,
        department?.trim() || null,
        password
      );
    } catch (emailError) {
      console.error('⚠️ Teacher created but email failed:', emailError.message);
      // Don't fail the request — teacher is already created
    }

    return res.status(201).json({
      success: true,
      message: 'Teacher account created successfully. Credentials sent to email.',
      data: {
        id: newUserId,
        name: name.trim(),
        email: normalizedEmail,
        contactNumber: String(contactNumber).trim(),
        teacherId: normalizedTeacherId,
        department: department?.trim() || null,
        role: 'faculty',
        is_active: true
      }
    });
  } catch (error) {
    console.error('Error creating teacher account:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to create teacher account.',
      error: error.message
    });
  }
});

/**
 * Router ko export kar rahe hain - app.js mein use hoga
 * 
 * app.js mein usage:
 * const authRoutes = require('./routes/auth/auth.routes');
 * app.use('/api/auth', authRoutes);
 * 
 * Final URLs:
 * - POST /api/auth/login
 * - POST /api/auth/logout
 * - GET /api/auth/me
 * - POST /api/auth/register
 * - PUT /api/auth/profile
 * - GET /api/auth/students
 * 
 * Kyun '/api/auth' prefix?
 * - API versioning: /api/v1/auth (future mein versioning ke liye)
 * - Organization: Sab API routes /api se start - clear structure
 * - Separation: API routes aur static files alag - routing clear
 */
module.exports = router;

// ============================================================================
// IMPORTANT NOTES:
// ============================================================================
//
// 1. Route Definition Pattern:
//    router.METHOD('/path', controllerFunction)
//    - METHOD: GET, POST, PUT, DELETE, etc.
//    - '/path': Route path (e.g., '/login', '/logout')
//    - controllerFunction: Controller function jo execute hogi
//
// 2. No Business Logic:
//    - Yahan sirf route definitions hain
//    - Business logic controllers aur services mein hogi
//    - Routes bas URL map karte hain controller functions se
//
// 3. Request Flow:
//    Frontend → Route → Controller → Service → Database → Service → Controller → Route → Frontend
//
// 4. Adding New Routes:
//    - Naya route add karna ho to yahan add karo
//    - Controller function pehle se exist karni chahiye
//    - Route path clear aur RESTful honi chahiye
//
// 5. Middleware Integration:
//    - Authentication middleware add kar sakte hain: router.get('/me', authenticate, getCurrentUser)
//    - Validation middleware add kar sakte hain: router.post('/login', validateLogin, login)
//    - Middleware routes ko modify karne se pehle add karein
//
// 6. Best Practices:
//    - Route paths clear aur descriptive honi chahiye
//    - RESTful conventions follow karo (GET for read, POST for create, etc.)
//    - Related routes ek hi file mein group karo
//    - Route file ka naam resource ke naam se match karo (auth.routes.js for auth routes)
//
// ============================================================================

